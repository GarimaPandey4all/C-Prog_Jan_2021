#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arr1[5], i;// declaration

    //Traditional way of initialization
    int arr[5] = {10, 20, 30, 40, 50}; //declaration and initialization

    //Compile Time Initialization
    int arr2[] = {1, 2, 3, 4, 5, 6, 7};

    printf("first value of array is: %d\n", arr[0]);
    printf("Third value of array is: %d\n", arr[2]);

    printf("Array:");
    for(i = 0; i < 5; i++)
    {
        printf("%d  ", arr[i]);
    }

    printf("\nArray:\n");
    for(i = 0; i < 7; i++)
    {
        printf("%d  ", arr2[i]);
    }


    printf("\nEnter values:\n");
    for(i = 0; i < 5; i++)
    {
        scanf("%d", &arr1[i]);
    }

    printf("Values in Array are:\n");
    for(i = 0; i < 5; i++)
    {
        printf("%d  ", arr1[i]);
    }

    return 0;
}
