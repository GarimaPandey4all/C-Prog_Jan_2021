#include <stdio.h>
#include <stdlib.h>

union Date
{
    int day;
    int month;
    int year;
}date, *pdate;

//union Date date, date1, date2;

int main()
{
    //union Date date;

    pdate = &date;

    pdate->day = 7;

    printf("Day is: %d ", pdate->day);

    pdate->month = 2;

    printf("Month is: %d ", pdate->month);

    pdate->year = 2021;

    printf("Year is: %d", pdate->year);

    //printf("Day: %d, Month: %d and Year: %d", date.day, date.month, date.year);

    return 0;
}
