#include <stdio.h>
#include <stdlib.h>

int factorial(int n)
{
    int result;

    if(n == 1)  // base condition or terminate condition
        return n;

    result = n * factorial(n - 1); // processing logic

    return result;
}

int main()
{
    int fact = 0;
    int n;

    printf("Enter any number:");
    scanf("%d", &n);

    fact = factorial(n);

    printf("Factorial Number is: %d", fact);

    return 0;
}
