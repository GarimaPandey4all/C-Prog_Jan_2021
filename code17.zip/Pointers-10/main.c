#include <stdio.h>
#include <stdlib.h>

//12 bytes

struct Date
{
    int day;
    int month;
    int year;
}date, *date1;

//struct Date date, date1, date2;

int main()
{
    //struct Date date, date1, date2;

    date1 = &date;

    date1->day = 1;
    (*date1).month = 10;
    date1->year = 2020;

    printf("Day = %d, Month = %d and Year= %d\n", date1->day, date1->month, date1->year);

    return 0;
}
