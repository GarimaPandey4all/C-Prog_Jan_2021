#include <stdio.h>
#include <stdlib.h>

/*
    malloc():

    malloc stands for memory allocation

    The malloc() function reserves the block of memory of the specified memory of bytes.
    Ans, it returns a pointer of void which can be casted into pointers of any type / form.

    Syntax:

    ptr = (casttype *)malloc(size);

*/


int main()
{
    int size;
    char *text = NULL;

    printf("Enter limit of the text:");
    scanf("%d", &size);

    //Memory Allocation
    text = (char *)malloc(size * sizeof(char)); // char : 1 byte

    if(text != NULL)
    {
        printf("Enter some text:");
        scanf(" ");
        gets(text);

        printf("Inputted text is: %s", text);
    }

    //Memory Deallocation
    free(text);
    text = NULL;

    return 0;
}
