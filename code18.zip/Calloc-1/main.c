#include <stdio.h>
#include <stdlib.h>

/*
    calloc():

    calloc stands for contiguous memory allocation

    The malloc() function allocates memory and leaves the memory uninitialized.
    Whereas, the calloc() function allocates memory and initialized all bits to zero.

    Syntax:

    ptr = (casttype *)calloc(n, size);

*/


int main()
{
    int size;
    char *text = NULL;

    printf("Enter limit of the text:");
    scanf("%d", &size);

    //Memory Allocation
    text = (char *)calloc(size, sizeof(char)); // char : 1 byte

    if(text != NULL)
    {
        printf("Enter some text:");
        scanf(" ");
        gets(text);

        printf("Inputted text is: %s", text);
    }

    //Memory Deallocation
    free(text);
    text = NULL;

    return 0;
}
