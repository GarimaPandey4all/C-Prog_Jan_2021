#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fp = NULL;  //FILE: Structure pointer which is already defined in C.

    char ch;

    fp = fopen("file.txt", "r"); // read mode

    if(fp == NULL)
    {
        printf("Error in Opening File");
        exit(0);
    }

    while((ch = getc(fp)) != EOF) // EOF: End of File
    {
        printf("%c", ch);
    }

    fclose(fp);
    fp = NULL;

    return 0;
}
