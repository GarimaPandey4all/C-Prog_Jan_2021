#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fp = NULL;

    fp = fopen("file.txt", "r");

    char ch;

    int linesCount = 1;

    if(fp ==  NULL)
    {
        printf("Error in opening file");
        exit(0);
    }

    while((ch = getc(fp)) != EOF)
    {
        if(ch == '\n')
        {
            linesCount++;
        }
    }

    printf("Total number of lines in file are: %d", linesCount);

    fclose(fp);
    fp = NULL;

    return 0;
}
