#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fp = NULL;

    fp = fopen("file.txt", "a"); //a - append mode

    if(fp != NULL)
    {
        fprintf(fp, "\n%s %d", "Hello", 103);
    }

    fclose(fp);
    fp = NULL;

    return 0;
}
