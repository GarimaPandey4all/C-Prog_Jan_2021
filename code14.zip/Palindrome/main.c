#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, temp, r, sum = 0;

    printf("Enter a number to check whether the number is palindrome or not:");
    scanf("%d", &n);

    temp = n;

    while(n > 0)
    {
        r = n % 10;
        sum = sum * 10 + r; // 121
        n = n / 10;
    }

    n= temp;

    if(n == sum)
        printf("Palindrome Number");
    else
        printf("Not a Palindrome Number");

    return 0;
}
