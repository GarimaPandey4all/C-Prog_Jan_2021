#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, r, reverse = 0;

    printf("Enter a number:");
    scanf("%d", &n);

    while(n > 0)
    {
        r = n % 10;
        reverse = reverse * 10 + r; // 121
        n = n / 10;
    }

    printf("Reverse number is: %d", reverse);

    return 0;
}
