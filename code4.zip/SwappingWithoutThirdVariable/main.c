#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, temp;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

//    printf("Before swapping the value of a=%d and b=%d\n", a, b);
//
//    //First - Way: + and -
//
//    a = a + b;
//    b = a - b;
//    a = a - b;
//
//    printf("After swapping the value of a=%d and b=%d", a, b);

//    printf("Before swapping the value of a=%d and b=%d\n", a, b);
//
//    //Second - Way: * and /
//
//    a = a * b;
//    b = a / b;
//    a = a / b;
//
//    printf("After swapping the value of a=%d and b=%d", a, b);

    printf("Before swapping the value of a=%d and b=%d\n", a, b);

    //Third - Way: ^ - X-OR

    a = a ^ b;
    b = a ^ b;
    a = a ^ b;

    printf("After swapping the value of a=%d and b=%d", a, b);

    return 0;
}
