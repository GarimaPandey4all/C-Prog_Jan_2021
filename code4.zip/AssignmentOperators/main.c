#include <stdio.h>
#include <stdlib.h>

int main()
{
    int sum = 50;

    sum += 10; // sum = sum + 10;

    printf("sum is: %d", sum);

    return 0;
}
