#include <stdio.h>
#include <stdlib.h>

union Date
{
    int day;
    int month;
    int year;
}date;

//union Date date, date1, date2;

int main()
{
    //union Date date;

    date.day = 7;

    printf("Day is: %d ", date.day);

    date.month = 2;

    printf("Month is: %d ", date.month);

    date.year = 2021;

    printf("Year is: %d", date.year);

    //printf("Day: %d, Month: %d and Year: %d", date.day, date.month, date.year);

    return 0;
}
