#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Enum: Enumeration : Group of constants

    enum Week {Monday = 1, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday};

    enum Week today = Sunday;

    printf("Today is: %d", today);

    return 0;
}
