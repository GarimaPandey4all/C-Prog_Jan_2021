#include <stdio.h>
#include <stdlib.h>

struct Date
{
    int day;
    int month;
    int year;
}date;

//struct Date date, date1, date2;

int main()
{
    //struct Date date;

    date.day = 7;
    date.month = 2;
    date.year = 2021;

    printf("Day: %d, Month: %d and Year: %d", date.day, date.month, date.year);

    return 0;
}
