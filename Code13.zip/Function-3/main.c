#include <stdio.h>
#include <stdlib.h>

//3. Function without argument and with return value

int Add();

int main()
{
    //int result = Add(); // call by value // Actual Arguments

    //printf("Addition is: %d", result);

    Add();

    return 0;
}

int Add() // Formal Arguments / Function Parameters
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is: %d", (a + b));

    //return (a + b);

    return 0;
}
