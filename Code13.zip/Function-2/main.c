#include <stdio.h>
#include <stdlib.h>

//2. Function with argument and without return value

void Add(int, int);

int main()
{
    Add(10, 20); // call by value // Actual Arguments

    return 0;
}

void Add(int a, int b) // Formal Arguments / Function Parameters
{
    printf("Addition is: %d", (a + b));
}
