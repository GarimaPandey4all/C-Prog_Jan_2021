#include <stdio.h>
#include <stdlib.h>

//Function - Reusability or Write once use many times

/*
    Function: Particular Task

    Function Types:
    1. Function without argument and without return value
    2. Function with argument and without return value
    3. Function without argument and with return value
    4. Function with argument and with return value

*/

//1. Function without argument and without return value

//Function Declaration/Create
void Add(); // void - null/empty/no return value

int main() // main()- entry point
{
    //function calling
    for(int i = 1; i <= 3; i++)
    {
        Add();
    }

    return 0;
}

//Function Definition
//Function Prototype - return type, name, function argument
void Add()
{
    int a, b;

    printf("\nEnter value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is: %d\n", (a + b));
}
