#include <stdio.h>
#include <stdlib.h>

//4. Function with argument and with return value

int Add(int, int);

int main()
{
    Add(10, 20); // call by value // Actual Arguments

    return 0;
}

int Add(int a, int b) // Formal Arguments / Function Parameters
{
    printf("Addition is: %d", (a + b));

    return 0;
}
