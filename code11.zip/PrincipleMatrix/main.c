#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j, rows, columns, matrix[5][5];

    printf("Enter number of rows and columns:");
    scanf("%d %d", &rows, &columns);

    printf("Enter values in Matrix:\n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            scanf("%d", &matrix[i][j]);
        }
    }


    printf("Values in Matrix:\n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }

    printf("Principle Matrix is: \n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            if(i == j)
            {
                printf("%d  ", matrix[i][j]);
            }
        }
    }

    return 0;
}
