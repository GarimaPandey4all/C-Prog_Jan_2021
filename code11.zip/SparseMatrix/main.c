#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j, rows, columns, matrix[5][5], count = 0;

    printf("Enter number of rows and columns:");
    scanf("%d %d", &rows, &columns);

    printf("Enter values in Matrix:\n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            scanf("%d", &matrix[i][j]);
        }
    }


    printf("Values in Matrix:\n");
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            printf("%d\t", matrix[i][j]);
        }
        printf("\n");
    }

    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < columns; j++)
        {
            if(matrix[i][j] == 0)
            {
                count++;
            }
        }
    }

    if(count > (rows * columns)/2)
    {
        printf("Sparse Matrix");
    }
    else
    {
        printf("Not a Sparse Matrix");
    }

    return 0;
}
