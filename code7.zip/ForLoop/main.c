#include <stdio.h>
#include <stdlib.h>

/*

    for loop:

    for(initialization; condition; increment/decrement)
    {
        //Block of code
    }


*/

int main()
{
    int n, i;

    printf("Enter any number that you want to print the table:");
    scanf("%d", &n);

    for(i = 1; i <= 20; i++)
    {
        printf("%d * %d = %d\n", n, i, n * i);
    }

    return 0;
}
