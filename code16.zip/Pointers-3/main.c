#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 100;

    int *pvalue = &value;

    int result = 0;

    result = *pvalue + 20;

    printf("Result is: %d", result);

    return 0;
}
