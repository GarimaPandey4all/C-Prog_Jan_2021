#include <stdio.h>
#include <stdlib.h>

int main()
{
    int Count = 10, x;

    int *pCount = &Count;

    x = *pCount;

    printf("X is: %d\n",x);

    printf("X is: %d", *pCount);

    return 0;
}
