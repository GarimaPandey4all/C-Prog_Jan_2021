#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 10;

    //int *pValue = &value;

    int *pValue = NULL;

    pValue = &value;

    printf("Value is: %d\n", value); // value

    printf("Value is: %d\n", *pValue); //Dereference operator = value

    printf("Value is: %d\n", pValue); // address of value

    printf("Value is: %d\n", &pValue); // address of pointer variable

    return 0;
}
