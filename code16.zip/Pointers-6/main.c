#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Pointer to a constant - value can't be changed
    // and Constant Pointer - address can't be changed

    const int value = 10;
    int number = 20;

    //Pointer to a constant
    //const int *pvalue = &value;

    //Constant Pointer
    //int *const pvalue = &value;

    const int *const pvalue = &value;

    *pvalue = 30; // error

    pvalue = &number;

    value = 40;

    return 0;
}
