#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i = 10;
    char ch = 'A';
    float j = 2.45f;

    void *ptr; // void pointer

    ptr = &i;
    printf("I is: %d", *(int *)ptr);

    ptr = &ch;
    printf("Ch is: %c", *(char *)ptr);

    ptr = &j;
    printf("J is: %f", *(float *)ptr);

    return 0;
}
