#include <stdio.h>
#include <stdlib.h>

int main()
{

    char str[] = "mumbai";
    int i;

    //lower to upper
    for(i = 0; str[i] != '\0'; i++)
    {
        str[i] = str[i] - 32;
    }

    printf("Uppercase is: %s\n", str);

    //Upper to lower
    for(i = 0; str[i] != '\0'; i++)
    {
        str[i] = str[i] + 32;
    }

    printf("Uppercase is: %s", str);

    return 0;
}
