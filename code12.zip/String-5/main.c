#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str[] = "How are you! Hello";
    int i, word = 1;

    for(i = 0; str[i] != '\0'; i++)
    {
        if(str[i] == ' ')
        {
            word++;
        }
    }

    printf("Word count of the string is: %d", word);

    return 0;
}
