#include <stdio.h>
#include <stdlib.h>

/*
    String Functions:

    1. String Length
    2. String Copy
    3. String Concatenation/Joining
    4. String Compare
    5. String Uppercase and Lowercase
*/

int main()
{
    char name[10];
    char name2[10];
    char str[10];

    printf("Enter your name:");
    gets(name);

    printf("Length of the string is: %d\n", strlen(name));

    printf("String 1 is copying in String 2:%s\n", strcpy(name2, name));

    printf("Concatenation is: %s\n", strcat(name, name2));

    printf("Enter name2:");
    gets(str);

    if(strcmp(name2, str) == 0)
    {
        printf("Same Strings\n");
    }
    else
    {
        printf("Not the Same Strings\n
               ");
    }

    printf("Uppercase String: %s\n", strupr(name2));

    printf("Lowercase String: %s", strlwr(name2));

    return 0;
}
