#include <stdio.h>
#include <stdlib.h>

//String: It is a collection of characters is called string.
//Characters of Arrays is called string in C.

int main()
{
    char name[10];

    printf("Enter your name:");
    //scanf("%s", &name);

    gets(name);

    puts(name);
    printf("Your name is: %s", name);

    return 0;
}
