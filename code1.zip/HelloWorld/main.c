#include <stdio.h>
#include <stdlib.h>

int main()
{
    //clrscr(); // error
    printf("Hello world!\n");
    getch();
    return 0;
}
