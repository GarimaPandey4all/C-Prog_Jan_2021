#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b); // a = 5, b = 6

    printf("Addition is: %d\n", (a + b));
    printf("Subtraction is: %d\n", (a - b));
    printf("Multiplication is: %d\n", (a * b));
    printf("Division is: %d\n", (a / b));
    printf("Modulus is: %d\n", (a % b));

    //Pre and Post Increment
    printf("Pre-Increment is: %d\n", ++a);
    printf("Post-Increment is: %d\n", a++); // a = 6
    printf("a is: %d\n", a);

    //Pre and Post Increment
    printf("Pre-Decrement is: %d\n", --b);
    printf("Post-Decrement is: %d\n", b--);
    printf("b is: %d\n", b);

    return 0;
}
