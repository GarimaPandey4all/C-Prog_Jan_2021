#include <stdio.h>
#include <stdlib.h>

int main()
{
    char ch;

    printf("Enter any character:");
    scanf("%c", &ch);

    printf("Entered charcter value is: %d\n", ch);

    printf("Address of ch: %u", &ch);

    return 0;
}
