#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Logical AND is: %d\n", (a == b && b < 10)); // 0
    printf("Logical OR is: %d\n", (a > b || b < 10)); // 1
    printf("Logical NOT is: %d\n", !(a > b && b < 10)); // 1

    return 0;
}
