#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Equal is: %d\n", (a == b));
    printf("Not Equal is: %d\n", (a != b));
    printf("Greater Than is: %d\n", (a > b));
    printf("Less Than is: %d\n", (a < b));
    printf("Greater than equal  is: %d\n", (a >= b));
    printf("Less than equal is: %d\n", (a <= b));

    return 0;
}
