#include <stdio.h>
#include <stdlib.h>

int main()
{
    int age = 18, ageLimit = 45;

    if(age >= 18)
    {
        if(age < ageLimit)
        {
            printf("You are eligible for this test");
        }
        else
        {
            printf("You are not eligible for this test");
        }
    }
    else
    {
        printf("Age is below 18");
    }

    return 0;
}
