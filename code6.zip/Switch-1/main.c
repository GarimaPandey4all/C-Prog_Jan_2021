#include <stdio.h>
#include <stdlib.h>

//Menu Driven Program - Switch

int main()
{
    int choice, a, b;

    printf("\n\nPress 1. Addition\n");
    printf("\nPress 2. Subtraction\n");
    printf("\nPress 3. Multiplication\n");
    printf("\nPress 4. Division\n");
    printf("\n\nEnter your choice:");
    scanf("%d", &choice);

    switch(choice)
    {
    case 1:
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Addition is: %d\n", (a + b));
        break;

    case 2:
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Subtraction is: %d\n", (a - b));
        break;

    case 3:
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Multiplication is: %d\n", (a * b));
        break;

    case 4:
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("Division is: %d\n", (a / b));
        break;

    default:
        printf("Invalid Choice");
    }

    return 0;
}
