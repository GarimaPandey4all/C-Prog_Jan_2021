#include <stdio.h>
#include <stdlib.h>

/*
    Ternary Operator / Conditional Operator

    ?:

    Ternary - 3

    (condition) ? true : false;
    expression-1 ? expression-2 : expression-3
*/

int main()
{
    int a, b;

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b);

    (a > b) ? printf("A is Greater") : printf("B is Greater");

    return 0;
}
