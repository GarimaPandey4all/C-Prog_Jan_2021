#include <stdio.h>
#include <stdlib.h>

int main()
{
    int eng, hindi, maths, social, history;
    float percentage, sum;

    printf("Enter your marks:");
    scanf("%d %d %d %d %d", &eng, &hindi, &maths, &social, &history);

    sum = eng + hindi + maths + social + history;

    printf("Sum is: %f\n", sum);

    percentage = sum / 5;

    printf("Percentage is: %f\n", percentage);

    if(percentage >= 50 && percentage <= 60)
        printf("D Grade");
    else if(percentage >= 60 && percentage <= 70)
        printf("C Grade");
    else if(percentage >= 70 && percentage <= 80)
        printf("B Grade");
    else if(percentage >= 80 && percentage <= 100)
        printf("A Grade");
    else
        printf("Fail...");

    return 0;
}
