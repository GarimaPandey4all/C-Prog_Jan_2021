#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 10, b = 20, c; // declaration and initialization

    c = a + b;

    printf("Addition is: %d", c);  // %d - Format Specifier

    return 0;
}
