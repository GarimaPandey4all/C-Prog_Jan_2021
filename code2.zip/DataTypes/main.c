#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 10; // int - 2 bytes or 4 bytes
    char ch = 'g'; // char - 1 byte
    float f = 56.78f; // float - 4bytes
    double d = 89.78; // double - 8 bytes

    printf("a is: %d\n", a);
    printf("ch is: %c\n", ch);
    printf("f is: %.2f\n", f);
    printf("d is: %lf\n", d);

    printf("Size of Int is: %d\n", sizeof(a));
    printf("Size of Char is: %d\n", sizeof(ch));
    printf("Size of Float is: %d\n", sizeof(float));
    printf("Size of Double is: %d\n", sizeof(d));

    return 0;
}
