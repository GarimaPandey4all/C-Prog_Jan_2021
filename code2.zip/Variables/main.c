#include <stdio.h>
#include <stdlib.h>

int main()
{
    const int a = 45; // constant - fixed value

    printf("a is: %d", a);

    //a = 70; // error

    //printf("a is: %d", a);

    return 0;
}
