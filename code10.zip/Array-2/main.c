#include <stdio.h>
#include <stdlib.h>
#define SIZE 12

int main()
{
    //const int SIZE = 12;
    int days[SIZE] = {31, 29, 30, 31, 30, 31, 30, 31, 30, 31, 30, 31};
    int i;

    for(i = 0; i < SIZE; i++)
    {
        printf("%d month has %d days\n", i + 1, days[i]);
    }

    return 0;
}
