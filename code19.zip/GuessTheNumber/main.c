#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    int number, guess, nGuesses = 1;

    srand(time(0));
    number = rand() % 100 + 1;
    //printf("The number is: %d\n", number);

    do
    {
        printf("Guess the number between 1 to 100\n");
        scanf("%d", &guess);

        if(guess > number)
        {
            printf("Enter Lower Number\n");
        }
        else if(guess < number)
        {
            printf("Enter Higher Number\n");
        }
        else
        {
            printf("You guessed the number in %d attempts\n", nGuesses);
        }

        nGuesses++;

    }while(guess != number);

    return 0;
}
