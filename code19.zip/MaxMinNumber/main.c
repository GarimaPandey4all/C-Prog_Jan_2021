#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a[10], i, max, min;

    printf("enter the numbers:\n");
    for(i=0; i<10; i++)
    {
        scanf("%d", &a[i]);
    }

    max = a[0];

    for(i=1; i<10; i++)
    {
        if(a[i] > max)
        {
            max = a[i];
        }
    }

    printf("maximum number is %d\n",max);

    min = a[0];

    for(i=1; i<10; i++)
    {
        if(a[i] < min)
        {
            min = a[i];
        }
    }

    printf("minimum number is %d\n",min);

    return 0;
}
